f=zeros(11);
%%% definir f como un filtro pasa-alta, hint: es una linea

imshow(conv2(single(x),f)+100,gray(256))  % las imagenes referencia se han creado asi
f45=imrotate(f,45,'crop');
figure
imshow(conv2(single(x),f45)+100,gray(256))
f90=imrotate(f,90,'crop');
figure
imshow(conv2(single(x),f90)+100,gray(256))
f135=imrotate(f,135,'crop');
figure
imshow(conv2(single(x),f135)+100,gray(256))
f180=imrotate(f,180,'crop');
figure
imshow(conv2(single(x),f180)+100,gray(256))
f215=imrotate(f,215,'crop');
figure
imshow(conv2(single(x),f215)+100,gray(256))